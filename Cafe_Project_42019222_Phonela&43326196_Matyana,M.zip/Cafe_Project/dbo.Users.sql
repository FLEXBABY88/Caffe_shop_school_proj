﻿CREATE TABLE [dbo].[Users] (
    [Name]     TEXT NOT NULL,
    [Password]    TEXT NULL,
    [Email] TEXT NULL
);

