﻿namespace Cafe_Project
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.cbCoffe4 = new System.Windows.Forms.CheckBox();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lblqp1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.picBxBasket = new System.Windows.Forms.PictureBox();
            this.lblBasket = new System.Windows.Forms.Label();
            this.cBox3 = new System.Windows.Forms.CheckBox();
            this.cBoxEspresso = new System.Windows.Forms.CheckBox();
            this.cBoxCappuccino = new System.Windows.Forms.CheckBox();
            this.cBoxAmericano = new System.Windows.Forms.CheckBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblTdesserts = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblDcount = new System.Windows.Forms.Label();
            this.lblItem5 = new System.Windows.Forms.Label();
            this.lblItem4 = new System.Windows.Forms.Label();
            this.lblItem3 = new System.Windows.Forms.Label();
            this.lblItem2 = new System.Windows.Forms.Label();
            this.lblItem1 = new System.Windows.Forms.Label();
            this.cboxD5 = new System.Windows.Forms.CheckBox();
            this.cboxD4 = new System.Windows.Forms.CheckBox();
            this.cboxD3 = new System.Windows.Forms.CheckBox();
            this.cboxD2 = new System.Windows.Forms.CheckBox();
            this.cboxD1 = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lblD5 = new System.Windows.Forms.Label();
            this.lblD4 = new System.Windows.Forms.Label();
            this.lblD3 = new System.Windows.Forms.Label();
            this.lblD2 = new System.Windows.Forms.Label();
            this.lblD1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lblTcoffee = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.cbCoffee4 = new System.Windows.Forms.CheckBox();
            this.cbCoffee3 = new System.Windows.Forms.CheckBox();
            this.cbCoffee2 = new System.Windows.Forms.CheckBox();
            this.cbCoffee1 = new System.Windows.Forms.CheckBox();
            this.Cofee4 = new System.Windows.Forms.Label();
            this.coffee3 = new System.Windows.Forms.Label();
            this.Coffee2 = new System.Windows.Forms.Label();
            this.Coffe1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.lblThdrinks = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.cbH4 = new System.Windows.Forms.CheckBox();
            this.cbH3 = new System.Windows.Forms.CheckBox();
            this.cbH2 = new System.Windows.Forms.CheckBox();
            this.cbH1 = new System.Windows.Forms.CheckBox();
            this.lblH4 = new System.Windows.Forms.Label();
            this.lblH3 = new System.Windows.Forms.Label();
            this.lblH2 = new System.Windows.Forms.Label();
            this.lblH1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBxBasket)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.ItemSize = new System.Drawing.Size(68, 23);
            this.tabControl1.Location = new System.Drawing.Point(0, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(804, 489);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabControl1.TabIndex = 1;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            this.tabControl1.Enter += new System.EventHandler(this.tabControl1_Enter);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Black;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage1.Controls.Add(this.cbCoffe4);
            this.tabPage1.Controls.Add(this.lbl4);
            this.tabPage1.Controls.Add(this.lbl3);
            this.tabPage1.Controls.Add(this.lbl2);
            this.tabPage1.Controls.Add(this.lblqp1);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.picBxBasket);
            this.tabPage1.Controls.Add(this.lblBasket);
            this.tabPage1.Controls.Add(this.cBox3);
            this.tabPage1.Controls.Add(this.cBoxEspresso);
            this.tabPage1.Controls.Add(this.cBoxCappuccino);
            this.tabPage1.Controls.Add(this.cBoxAmericano);
            this.tabPage1.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(796, 458);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Quick picks";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // cbCoffe4
            // 
            this.cbCoffe4.AutoSize = true;
            this.cbCoffe4.Location = new System.Drawing.Point(220, 363);
            this.cbCoffe4.Name = "cbCoffe4";
            this.cbCoffe4.Size = new System.Drawing.Size(15, 14);
            this.cbCoffe4.TabIndex = 34;
            this.cbCoffe4.UseVisualStyleBackColor = true;
            this.cbCoffe4.CheckedChanged += new System.EventHandler(this.cbCoffe4_CheckedChanged);
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbl4.Location = new System.Drawing.Point(21, 359);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(51, 20);
            this.lbl4.TabIndex = 33;
            this.lbl4.Text = "label3";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbl3.Location = new System.Drawing.Point(18, 309);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(60, 20);
            this.lbl3.TabIndex = 32;
            this.lbl3.Text = "label12";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbl2.Location = new System.Drawing.Point(18, 268);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(60, 20);
            this.lbl2.TabIndex = 31;
            this.lbl2.Text = "label11";
            // 
            // lblqp1
            // 
            this.lblqp1.AutoSize = true;
            this.lblqp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblqp1.Location = new System.Drawing.Point(18, 223);
            this.lblqp1.Name = "lblqp1";
            this.lblqp1.Size = new System.Drawing.Size(51, 20);
            this.lblqp1.TabIndex = 30;
            this.lblqp1.Text = "label3";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Freestyle Script", 27.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label1.Location = new System.Drawing.Point(225, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 44);
            this.label1.TabIndex = 17;
            this.label1.Text = "Beetle Caf";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(216, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 20);
            this.label2.TabIndex = 18;
            this.label2.Text = "Quick picks ? We got you!";
            // 
            // picBxBasket
            // 
            this.picBxBasket.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.picBxBasket.Image = ((System.Drawing.Image)(resources.GetObject("picBxBasket.Image")));
            this.picBxBasket.Location = new System.Drawing.Point(701, 81);
            this.picBxBasket.Name = "picBxBasket";
            this.picBxBasket.Size = new System.Drawing.Size(40, 31);
            this.picBxBasket.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBxBasket.TabIndex = 29;
            this.picBxBasket.TabStop = false;
            this.picBxBasket.Click += new System.EventHandler(this.picBxBasket_Click_1);
            // 
            // lblBasket
            // 
            this.lblBasket.AutoSize = true;
            this.lblBasket.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.lblBasket.Location = new System.Drawing.Point(747, 71);
            this.lblBasket.Name = "lblBasket";
            this.lblBasket.Size = new System.Drawing.Size(13, 13);
            this.lblBasket.TabIndex = 28;
            this.lblBasket.Text = "0";
            // 
            // cBox3
            // 
            this.cBox3.AutoSize = true;
            this.cBox3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.cBox3.Location = new System.Drawing.Point(220, 309);
            this.cBox3.Name = "cBox3";
            this.cBox3.Size = new System.Drawing.Size(15, 14);
            this.cBox3.TabIndex = 27;
            this.cBox3.UseVisualStyleBackColor = true;
            this.cBox3.CheckedChanged += new System.EventHandler(this.cBox3_CheckedChanged);
            // 
            // cBoxEspresso
            // 
            this.cBoxEspresso.AutoSize = true;
            this.cBoxEspresso.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.cBoxEspresso.Location = new System.Drawing.Point(220, 273);
            this.cBoxEspresso.Name = "cBoxEspresso";
            this.cBoxEspresso.Size = new System.Drawing.Size(15, 14);
            this.cBoxEspresso.TabIndex = 26;
            this.cBoxEspresso.UseVisualStyleBackColor = true;
            this.cBoxEspresso.CheckedChanged += new System.EventHandler(this.cBoxEspresso_CheckedChanged);
            // 
            // cBoxCappuccino
            // 
            this.cBoxCappuccino.AutoSize = true;
            this.cBoxCappuccino.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.cBoxCappuccino.Location = new System.Drawing.Point(220, 229);
            this.cBoxCappuccino.Name = "cBoxCappuccino";
            this.cBoxCappuccino.Size = new System.Drawing.Size(15, 14);
            this.cBoxCappuccino.TabIndex = 25;
            this.cBoxCappuccino.UseVisualStyleBackColor = true;
            this.cBoxCappuccino.CheckedChanged += new System.EventHandler(this.cBoxCappuccino_CheckedChanged_1);
            // 
            // cBoxAmericano
            // 
            this.cBoxAmericano.AutoSize = true;
            this.cBoxAmericano.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.cBoxAmericano.Location = new System.Drawing.Point(220, 181);
            this.cBoxAmericano.Name = "cBoxAmericano";
            this.cBoxAmericano.Size = new System.Drawing.Size(15, 14);
            this.cBoxAmericano.TabIndex = 20;
            this.cBoxAmericano.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Black;
            this.tabPage2.Controls.Add(this.lblTdesserts);
            this.tabPage2.Controls.Add(this.pictureBox1);
            this.tabPage2.Controls.Add(this.lblTotal);
            this.tabPage2.Controls.Add(this.lblDcount);
            this.tabPage2.Controls.Add(this.lblItem5);
            this.tabPage2.Controls.Add(this.lblItem4);
            this.tabPage2.Controls.Add(this.lblItem3);
            this.tabPage2.Controls.Add(this.lblItem2);
            this.tabPage2.Controls.Add(this.lblItem1);
            this.tabPage2.Controls.Add(this.cboxD5);
            this.tabPage2.Controls.Add(this.cboxD4);
            this.tabPage2.Controls.Add(this.cboxD3);
            this.tabPage2.Controls.Add(this.cboxD2);
            this.tabPage2.Controls.Add(this.cboxD1);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.lblD5);
            this.tabPage2.Controls.Add(this.lblD4);
            this.tabPage2.Controls.Add(this.lblD3);
            this.tabPage2.Controls.Add(this.lblD2);
            this.tabPage2.Controls.Add(this.lblD1);
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(796, 458);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Desserts";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            this.tabPage2.Enter += new System.EventHandler(this.tabPage2_Enter);
            // 
            // lblTdesserts
            // 
            this.lblTdesserts.AutoSize = true;
            this.lblTdesserts.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.lblTdesserts.Location = new System.Drawing.Point(622, 71);
            this.lblTdesserts.Name = "lblTdesserts";
            this.lblTdesserts.Size = new System.Drawing.Size(13, 13);
            this.lblTdesserts.TabIndex = 41;
            this.lblTdesserts.Text = "0";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(574, 83);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 31);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 40;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.lblTotal.Location = new System.Drawing.Point(500, 83);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(0, 13);
            this.lblTotal.TabIndex = 39;
            // 
            // lblDcount
            // 
            this.lblDcount.AutoSize = true;
            this.lblDcount.ForeColor = System.Drawing.SystemColors.Control;
            this.lblDcount.Location = new System.Drawing.Point(459, 264);
            this.lblDcount.Name = "lblDcount";
            this.lblDcount.Size = new System.Drawing.Size(0, 13);
            this.lblDcount.TabIndex = 38;
            this.lblDcount.Visible = false;
            // 
            // lblItem5
            // 
            this.lblItem5.AutoSize = true;
            this.lblItem5.Location = new System.Drawing.Point(439, 303);
            this.lblItem5.Name = "lblItem5";
            this.lblItem5.Size = new System.Drawing.Size(35, 13);
            this.lblItem5.TabIndex = 36;
            this.lblItem5.Text = "label1";
            // 
            // lblItem4
            // 
            this.lblItem4.AutoSize = true;
            this.lblItem4.Location = new System.Drawing.Point(500, 252);
            this.lblItem4.Name = "lblItem4";
            this.lblItem4.Size = new System.Drawing.Size(35, 13);
            this.lblItem4.TabIndex = 35;
            this.lblItem4.Text = "label1";
            // 
            // lblItem3
            // 
            this.lblItem3.AutoSize = true;
            this.lblItem3.Location = new System.Drawing.Point(304, 227);
            this.lblItem3.Name = "lblItem3";
            this.lblItem3.Size = new System.Drawing.Size(35, 13);
            this.lblItem3.TabIndex = 34;
            this.lblItem3.Text = "label1";
            // 
            // lblItem2
            // 
            this.lblItem2.AutoSize = true;
            this.lblItem2.Location = new System.Drawing.Point(301, 180);
            this.lblItem2.Name = "lblItem2";
            this.lblItem2.Size = new System.Drawing.Size(35, 13);
            this.lblItem2.TabIndex = 33;
            this.lblItem2.Text = "label2";
            // 
            // lblItem1
            // 
            this.lblItem1.AutoSize = true;
            this.lblItem1.Location = new System.Drawing.Point(310, 134);
            this.lblItem1.Name = "lblItem1";
            this.lblItem1.Size = new System.Drawing.Size(35, 13);
            this.lblItem1.TabIndex = 32;
            this.lblItem1.Text = "label1";
            // 
            // cboxD5
            // 
            this.cboxD5.AutoSize = true;
            this.cboxD5.Location = new System.Drawing.Point(269, 303);
            this.cboxD5.Name = "cboxD5";
            this.cboxD5.Size = new System.Drawing.Size(15, 14);
            this.cboxD5.TabIndex = 31;
            this.cboxD5.UseVisualStyleBackColor = true;
            this.cboxD5.CheckedChanged += new System.EventHandler(this.cboxD5_CheckedChanged);
            // 
            // cboxD4
            // 
            this.cboxD4.AutoSize = true;
            this.cboxD4.Location = new System.Drawing.Point(269, 262);
            this.cboxD4.Name = "cboxD4";
            this.cboxD4.Size = new System.Drawing.Size(15, 14);
            this.cboxD4.TabIndex = 30;
            this.cboxD4.UseVisualStyleBackColor = true;
            this.cboxD4.CheckedChanged += new System.EventHandler(this.cboxD4_CheckedChanged);
            // 
            // cboxD3
            // 
            this.cboxD3.AutoSize = true;
            this.cboxD3.Location = new System.Drawing.Point(269, 225);
            this.cboxD3.Name = "cboxD3";
            this.cboxD3.Size = new System.Drawing.Size(15, 14);
            this.cboxD3.TabIndex = 29;
            this.cboxD3.UseVisualStyleBackColor = true;
            this.cboxD3.CheckedChanged += new System.EventHandler(this.cboxD3_CheckedChanged);
            // 
            // cboxD2
            // 
            this.cboxD2.AutoSize = true;
            this.cboxD2.Location = new System.Drawing.Point(269, 179);
            this.cboxD2.Name = "cboxD2";
            this.cboxD2.Size = new System.Drawing.Size(15, 14);
            this.cboxD2.TabIndex = 28;
            this.cboxD2.UseVisualStyleBackColor = true;
            this.cboxD2.CheckedChanged += new System.EventHandler(this.cboxD2_CheckedChanged);
            // 
            // cboxD1
            // 
            this.cboxD1.AutoSize = true;
            this.cboxD1.Location = new System.Drawing.Point(269, 132);
            this.cboxD1.Name = "cboxD1";
            this.cboxD1.Size = new System.Drawing.Size(15, 14);
            this.cboxD1.TabIndex = 27;
            this.cboxD1.UseVisualStyleBackColor = true;
            this.cboxD1.CheckedChanged += new System.EventHandler(this.cboxD1_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Freestyle Script", 27.75F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label6.Location = new System.Drawing.Point(305, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 44);
            this.label6.TabIndex = 26;
            this.label6.Text = "Desserts";
            // 
            // lblD5
            // 
            this.lblD5.AutoSize = true;
            this.lblD5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblD5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblD5.Location = new System.Drawing.Point(62, 305);
            this.lblD5.Name = "lblD5";
            this.lblD5.Size = new System.Drawing.Size(51, 20);
            this.lblD5.TabIndex = 25;
            this.lblD5.Text = "label5";
            // 
            // lblD4
            // 
            this.lblD4.AutoSize = true;
            this.lblD4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblD4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblD4.Location = new System.Drawing.Point(62, 264);
            this.lblD4.Name = "lblD4";
            this.lblD4.Size = new System.Drawing.Size(51, 20);
            this.lblD4.TabIndex = 24;
            this.lblD4.Text = "label4";
            // 
            // lblD3
            // 
            this.lblD3.AutoSize = true;
            this.lblD3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblD3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblD3.Location = new System.Drawing.Point(62, 222);
            this.lblD3.Name = "lblD3";
            this.lblD3.Size = new System.Drawing.Size(51, 20);
            this.lblD3.TabIndex = 23;
            this.lblD3.Text = "label3";
            // 
            // lblD2
            // 
            this.lblD2.AutoSize = true;
            this.lblD2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblD2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblD2.Location = new System.Drawing.Point(62, 175);
            this.lblD2.Name = "lblD2";
            this.lblD2.Size = new System.Drawing.Size(51, 20);
            this.lblD2.TabIndex = 22;
            this.lblD2.Text = "label2";
            // 
            // lblD1
            // 
            this.lblD1.AutoSize = true;
            this.lblD1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblD1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblD1.Location = new System.Drawing.Point(62, 128);
            this.lblD1.Name = "lblD1";
            this.lblD1.Size = new System.Drawing.Size(33, 20);
            this.lblD1.TabIndex = 21;
            this.lblD1.Text = "null";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Black;
            this.tabPage3.Controls.Add(this.lblTcoffee);
            this.tabPage3.Controls.Add(this.pictureBox2);
            this.tabPage3.Controls.Add(this.cbCoffee4);
            this.tabPage3.Controls.Add(this.cbCoffee3);
            this.tabPage3.Controls.Add(this.cbCoffee2);
            this.tabPage3.Controls.Add(this.cbCoffee1);
            this.tabPage3.Controls.Add(this.Cofee4);
            this.tabPage3.Controls.Add(this.coffee3);
            this.tabPage3.Controls.Add(this.Coffee2);
            this.tabPage3.Controls.Add(this.Coffe1);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.tabPage3.Location = new System.Drawing.Point(4, 27);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(796, 458);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Coffee";
            this.tabPage3.DragOver += new System.Windows.Forms.DragEventHandler(this.tabPage3_DragOver);
            this.tabPage3.Enter += new System.EventHandler(this.tabPage3_Enter);
            // 
            // lblTcoffee
            // 
            this.lblTcoffee.AutoSize = true;
            this.lblTcoffee.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.lblTcoffee.Location = new System.Drawing.Point(574, 66);
            this.lblTcoffee.Name = "lblTcoffee";
            this.lblTcoffee.Size = new System.Drawing.Size(13, 13);
            this.lblTcoffee.TabIndex = 42;
            this.lblTcoffee.Text = "0";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(531, 85);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 31);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 41;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // cbCoffee4
            // 
            this.cbCoffee4.AutoSize = true;
            this.cbCoffee4.Location = new System.Drawing.Point(230, 306);
            this.cbCoffee4.Name = "cbCoffee4";
            this.cbCoffee4.Size = new System.Drawing.Size(15, 14);
            this.cbCoffee4.TabIndex = 17;
            this.cbCoffee4.UseVisualStyleBackColor = true;
            this.cbCoffee4.CheckedChanged += new System.EventHandler(this.cbCoffee4_CheckedChanged);
            // 
            // cbCoffee3
            // 
            this.cbCoffee3.AutoSize = true;
            this.cbCoffee3.Location = new System.Drawing.Point(230, 233);
            this.cbCoffee3.Name = "cbCoffee3";
            this.cbCoffee3.Size = new System.Drawing.Size(15, 14);
            this.cbCoffee3.TabIndex = 16;
            this.cbCoffee3.UseVisualStyleBackColor = true;
            this.cbCoffee3.CheckedChanged += new System.EventHandler(this.cbCoffee3_CheckedChanged);
            // 
            // cbCoffee2
            // 
            this.cbCoffee2.AutoSize = true;
            this.cbCoffee2.Location = new System.Drawing.Point(230, 171);
            this.cbCoffee2.Name = "cbCoffee2";
            this.cbCoffee2.Size = new System.Drawing.Size(15, 14);
            this.cbCoffee2.TabIndex = 15;
            this.cbCoffee2.UseVisualStyleBackColor = true;
            this.cbCoffee2.CheckedChanged += new System.EventHandler(this.cbCoffee2_CheckedChanged);
            // 
            // cbCoffee1
            // 
            this.cbCoffee1.AutoSize = true;
            this.cbCoffee1.Location = new System.Drawing.Point(230, 117);
            this.cbCoffee1.Name = "cbCoffee1";
            this.cbCoffee1.Size = new System.Drawing.Size(15, 14);
            this.cbCoffee1.TabIndex = 14;
            this.cbCoffee1.UseVisualStyleBackColor = true;
            this.cbCoffee1.CheckedChanged += new System.EventHandler(this.cbCoffee1_CheckedChanged);
            // 
            // Cofee4
            // 
            this.Cofee4.AutoSize = true;
            this.Cofee4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Cofee4.Location = new System.Drawing.Point(34, 302);
            this.Cofee4.Name = "Cofee4";
            this.Cofee4.Size = new System.Drawing.Size(51, 20);
            this.Cofee4.TabIndex = 13;
            this.Cofee4.Text = "label5";
            // 
            // coffee3
            // 
            this.coffee3.AutoSize = true;
            this.coffee3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.coffee3.Location = new System.Drawing.Point(34, 233);
            this.coffee3.Name = "coffee3";
            this.coffee3.Size = new System.Drawing.Size(51, 20);
            this.coffee3.TabIndex = 12;
            this.coffee3.Text = "label4";
            // 
            // Coffee2
            // 
            this.Coffee2.AutoSize = true;
            this.Coffee2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Coffee2.Location = new System.Drawing.Point(34, 171);
            this.Coffee2.Name = "Coffee2";
            this.Coffee2.Size = new System.Drawing.Size(51, 20);
            this.Coffee2.TabIndex = 11;
            this.Coffee2.Text = "label3";
            // 
            // Coffe1
            // 
            this.Coffe1.AutoSize = true;
            this.Coffe1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Coffe1.Location = new System.Drawing.Point(34, 117);
            this.Coffe1.Name = "Coffe1";
            this.Coffe1.Size = new System.Drawing.Size(35, 20);
            this.Coffe1.TabIndex = 10;
            this.Coffe1.Text = "Null";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Freestyle Script", 27.75F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label4.Location = new System.Drawing.Point(252, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 44);
            this.label4.TabIndex = 9;
            this.label4.Text = "COFEE";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Black;
            this.tabPage4.Controls.Add(this.lblThdrinks);
            this.tabPage4.Controls.Add(this.pictureBox3);
            this.tabPage4.Controls.Add(this.cbH4);
            this.tabPage4.Controls.Add(this.cbH3);
            this.tabPage4.Controls.Add(this.cbH2);
            this.tabPage4.Controls.Add(this.cbH1);
            this.tabPage4.Controls.Add(this.lblH4);
            this.tabPage4.Controls.Add(this.lblH3);
            this.tabPage4.Controls.Add(this.lblH2);
            this.tabPage4.Controls.Add(this.lblH1);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Location = new System.Drawing.Point(4, 27);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(796, 458);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Hot drinks";
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            this.tabPage4.Enter += new System.EventHandler(this.tabPage4_Enter);
            // 
            // lblThdrinks
            // 
            this.lblThdrinks.AutoSize = true;
            this.lblThdrinks.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.lblThdrinks.Location = new System.Drawing.Point(574, 57);
            this.lblThdrinks.Name = "lblThdrinks";
            this.lblThdrinks.Size = new System.Drawing.Size(13, 13);
            this.lblThdrinks.TabIndex = 42;
            this.lblThdrinks.Text = "0";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(534, 73);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(40, 31);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 41;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // cbH4
            // 
            this.cbH4.AutoSize = true;
            this.cbH4.Location = new System.Drawing.Point(288, 334);
            this.cbH4.Name = "cbH4";
            this.cbH4.Size = new System.Drawing.Size(80, 17);
            this.cbH4.TabIndex = 17;
            this.cbH4.Text = "checkBox3";
            this.cbH4.UseVisualStyleBackColor = true;
            this.cbH4.CheckedChanged += new System.EventHandler(this.cbH4_CheckedChanged);
            // 
            // cbH3
            // 
            this.cbH3.AutoSize = true;
            this.cbH3.Location = new System.Drawing.Point(288, 263);
            this.cbH3.Name = "cbH3";
            this.cbH3.Size = new System.Drawing.Size(80, 17);
            this.cbH3.TabIndex = 16;
            this.cbH3.Text = "checkBox2";
            this.cbH3.UseVisualStyleBackColor = true;
            this.cbH3.CheckedChanged += new System.EventHandler(this.cbH3_CheckedChanged);
            // 
            // cbH2
            // 
            this.cbH2.AutoSize = true;
            this.cbH2.Location = new System.Drawing.Point(288, 212);
            this.cbH2.Name = "cbH2";
            this.cbH2.Size = new System.Drawing.Size(80, 17);
            this.cbH2.TabIndex = 15;
            this.cbH2.Text = "checkBox1";
            this.cbH2.UseVisualStyleBackColor = true;
            this.cbH2.CheckedChanged += new System.EventHandler(this.cbH2_CheckedChanged);
            // 
            // cbH1
            // 
            this.cbH1.AutoSize = true;
            this.cbH1.Location = new System.Drawing.Point(288, 145);
            this.cbH1.Name = "cbH1";
            this.cbH1.Size = new System.Drawing.Size(80, 17);
            this.cbH1.TabIndex = 14;
            this.cbH1.Text = "checkBox1";
            this.cbH1.UseVisualStyleBackColor = true;
            this.cbH1.CheckedChanged += new System.EventHandler(this.cbH1_CheckedChanged);
            this.cbH1.Enter += new System.EventHandler(this.cbH1_Enter);
            // 
            // lblH4
            // 
            this.lblH4.AutoSize = true;
            this.lblH4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblH4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblH4.Location = new System.Drawing.Point(40, 334);
            this.lblH4.Name = "lblH4";
            this.lblH4.Size = new System.Drawing.Size(51, 20);
            this.lblH4.TabIndex = 13;
            this.lblH4.Text = "label5";
            // 
            // lblH3
            // 
            this.lblH3.AutoSize = true;
            this.lblH3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblH3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblH3.Location = new System.Drawing.Point(40, 263);
            this.lblH3.Name = "lblH3";
            this.lblH3.Size = new System.Drawing.Size(51, 20);
            this.lblH3.TabIndex = 12;
            this.lblH3.Text = "label4";
            // 
            // lblH2
            // 
            this.lblH2.AutoSize = true;
            this.lblH2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblH2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblH2.Location = new System.Drawing.Point(40, 212);
            this.lblH2.Name = "lblH2";
            this.lblH2.Size = new System.Drawing.Size(51, 20);
            this.lblH2.TabIndex = 11;
            this.lblH2.Text = "label3";
            // 
            // lblH1
            // 
            this.lblH1.AutoSize = true;
            this.lblH1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblH1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblH1.Location = new System.Drawing.Point(40, 145);
            this.lblH1.Name = "lblH1";
            this.lblH1.Size = new System.Drawing.Size(35, 20);
            this.lblH1.TabIndex = 10;
            this.lblH1.Text = "Null";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Freestyle Script", 27.75F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label10.Location = new System.Drawing.Point(266, 41);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(141, 44);
            this.label10.TabIndex = 9;
            this.label10.Text = "Hot drinks ";
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 488);
            this.Controls.Add(this.tabControl1);
            this.Name = "Menu";
            this.Text = "Menu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Menu_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBxBasket)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblDcount;
        private System.Windows.Forms.Label lblItem5;
        private System.Windows.Forms.Label lblItem4;
        private System.Windows.Forms.Label lblItem3;
        private System.Windows.Forms.Label lblItem2;
        private System.Windows.Forms.Label lblItem1;
        private System.Windows.Forms.CheckBox cboxD5;
        private System.Windows.Forms.CheckBox cboxD4;
        private System.Windows.Forms.CheckBox cboxD3;
        private System.Windows.Forms.CheckBox cboxD2;
        public System.Windows.Forms.CheckBox cboxD1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblD5;
        private System.Windows.Forms.Label lblD4;
        private System.Windows.Forms.Label lblD3;
        private System.Windows.Forms.Label lblD2;
        public System.Windows.Forms.Label lblD1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.CheckBox cbCoffee4;
        private System.Windows.Forms.CheckBox cbCoffee3;
        private System.Windows.Forms.CheckBox cbCoffee2;
        private System.Windows.Forms.CheckBox cbCoffee1;
        private System.Windows.Forms.Label Cofee4;
        private System.Windows.Forms.Label coffee3;
        private System.Windows.Forms.Label Coffee2;
        private System.Windows.Forms.Label Coffe1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox cbH4;
        private System.Windows.Forms.CheckBox cbH3;
        private System.Windows.Forms.CheckBox cbH2;
        private System.Windows.Forms.CheckBox cbH1;
        private System.Windows.Forms.Label lblH4;
        private System.Windows.Forms.Label lblH3;
        private System.Windows.Forms.Label lblH2;
        private System.Windows.Forms.Label lblH1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lblqp1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox picBxBasket;
        public System.Windows.Forms.Label lblBasket;
        private System.Windows.Forms.CheckBox cBox3;
        private System.Windows.Forms.CheckBox cBoxEspresso;
        private System.Windows.Forms.CheckBox cBoxCappuccino;
        private System.Windows.Forms.CheckBox cBoxAmericano;
        private System.Windows.Forms.CheckBox cbCoffe4;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lblTdesserts;
        private System.Windows.Forms.Label lblTcoffee;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblThdrinks;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}