﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using BeetleCaf_Project;

namespace Cafe_Project
{
    public partial class Menu : Form
    {
        private Basket myBasket; //declaring a private basket instance
        public Label mylabel = new Label();
        public Admin myAdmin;

        private int DessertsCount;
        private ListBox desserts = new ListBox();
        private Label Itemslbl = new Label();

        public Menu()
        {
            InitializeComponent();
            myBasket = new Basket();
            myAdmin = new Admin(); 

        }





        public string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Nhlanhla\Desktop\New folder\Cafe_Project\Users.mdf"";Integrated Security=True";
        SqlConnection sqlcon;
        SqlDataReader read;
        public int Qpick1, Qpick2, Qpick3, Qpick4;//the quantities of the quick picks 

        string Hotdrinks = ""; 
        public void displayHotDrinks()
        {
            try
            {

                lblThdrinks.Text = lblBasket.Text; 
                sqlcon = new SqlConnection(constr);
                sqlcon.Open();
                SqlCommand cmd = new SqlCommand(@"SELECT * FROM items ", sqlcon);
                read = cmd.ExecuteReader();
                while (read.Read()) // getting the menu from the database abd populating it to the user 
                {


                    if (read.GetValue(0).ToString() == "4")
                    {

                        // lblH1.Text = read.GetValue(2).ToString();
                        lblH1.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();
                        Hotdrinks = read.GetValue(1).ToString(); 

                    }
                    else if (read.GetValue(0).ToString() == "5")
                    {
                        // lblH2.Text = read.GetValue(2).ToString();
                        lblH2.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();
                        Hotdrinks = read.GetValue(1).ToString();
                    }
                    else if (read.GetValue(0).ToString() == "6")
                    {
                        //lblH3.Text = read.GetValue(2).ToString();
                        lblH3.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();
                        Hotdrinks = read.GetValue(1).ToString();
                    }
                    else if (read.GetValue(0).ToString() == "7")
                    {
                        //lblH4.Text = read.GetValue(2).ToString();
                        lblH4.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();
                        Hotdrinks = read.GetValue(1).ToString();

                    }

                }






                sqlcon.Close();


            }
            catch (SqlException exce)
            {
                MessageBox.Show(exce.Message);
            }
        }





        private void Menu_Load(object sender, EventArgs e)
        {
           

            displayHotDrinks();

            try
            {
                sqlcon = new SqlConnection(constr);
                sqlcon.Open();
                SqlCommand cmd = new SqlCommand(@"SELECT * FROM items", sqlcon);
                read = cmd.ExecuteReader();
                while (read.Read()) // getting the menu from the database 
                {
                    if (read.GetValue(0).ToString() == "0")
                    {


                        lblqp1.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();
                        Qpick1 = int.Parse(read.GetValue(3).ToString());
                        
                    }
                    else if (read.GetValue(0).ToString() == "1")
                    {
                        lbl2.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();
                        Qpick2 = int.Parse(read.GetValue(3).ToString());
                    }
                    else if (read.GetValue(0).ToString() == "2")
                    {
                        lbl3.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();
                        Qpick3 = int.Parse(read.GetValue(3).ToString());
                    }
                    else if (read.GetValue(0).ToString() == "3")
                    {
                        Cofee4.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();
                        lbl4.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();
                        Qpick4 = int.Parse(read.GetValue(3).ToString());
                    }
                }






                sqlcon.Close();


            }
            catch (SqlException exce)
            {
                MessageBox.Show(exce.Message);
            }




        }







        private void picBxBasket_Click_1(object sender, EventArgs e) 
        {
            myBasket.ShowDialog(); //calling the basket form by the picture box
        }

        private void cBoxCappuccino_CheckedChanged_1(object sender, EventArgs e)
        {
            if (cBoxCappuccino.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(lblqp1.Text);
                myAdmin.lstOrders.Items.Add(lblqp1.Text);
                myBasket.ItemType.Items.Add("Coffee");
               
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();

                Qpick4--;
            }
            else if (cBox3.Checked == false)
            {
                myBasket.listBasket.Items.Remove(lblqp1.Text);//Removing Items in the listbox
               
                myBasket.ItemType.Items.Remove("Coffee");

                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                Qpick4++;
            }

        }

        private void cbCoffe4_CheckedChanged(object sender, EventArgs e)
        {
            if (cbCoffe4.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(lbl4.Text);
               
                myBasket.ItemType.Items.Add("Coffee");
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString(); //displaying the number of items in the basket
                Qpick3--;

            }
            else if (cbCoffe4.Checked == false)
            {
                myBasket.ItemType.Items.Remove("Coffee");
                myBasket.listBasket.Items.Remove(lbl4.Text);//Removing Items in the listbox
               

                lblBasket.Text = myBasket.listBasket.Items.Count.ToString(); //displaying the number of items in the basket
                Qpick3++;
            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {



        }

        private void tabPage2_Enter(object sender, EventArgs e) //Desserts page
        {
            lblTdesserts.Text=lblBasket.Text;
            
            try
            {

                sqlcon = new SqlConnection(constr);
                sqlcon.Open();
                SqlCommand cmd = new SqlCommand(@"SELECT * FROM items WHERE Item_Type ='Desserts' ", sqlcon);
                read = cmd.ExecuteReader();
                while (read.Read()) // getting the menu from the database abd populating it to the user 
                {


                    if (read.GetValue(0).ToString() == "8")
                    {

                        lblItem1.Text = read.GetValue(2).ToString();
                        lblD1.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();

                    }
                    else if (read.GetValue(0).ToString() == "9")
                    {
                        lblItem2.Text = read.GetValue(2).ToString();
                        lblD2.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();

                    }
                    else if (read.GetValue(0).ToString() == "10")
                    {
                        lblItem3.Text = read.GetValue(2).ToString();
                        lblD3.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();

                    }
                    else if (read.GetValue(0).ToString() == "11")
                    {
                        lblItem4.Text = read.GetValue(2).ToString();
                        lblD4.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();

                    }
                    else if (read.GetValue(0).ToString() == "12")
                    {
                        lblItem5.Text = read.GetValue(2).ToString();
                        lblD5.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();

                    }
                }






                sqlcon.Close();


            }
            catch (SqlException exce)
            {
                MessageBox.Show(exce.Message);
            }
        }

        private void tabPage3_Enter(object sender, EventArgs e) //Coffe tabpage
        {
            lblTcoffee.Text = lblBasket.Text;
            


            try
            {
                sqlcon = new SqlConnection(constr);
                sqlcon.Open();
                SqlCommand cmd = new SqlCommand(@"SELECT * FROM items  WHERE Item_Type ='Coffee'", sqlcon);
                read = cmd.ExecuteReader();
                while (read.Read()) // getting the menu from the database 
                {
                    if (read.GetValue(0).ToString() == "0")
                    {


                        Coffe1.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();
                        Qpick1 = int.Parse(read.GetValue(3).ToString());
                    }
                    else if (read.GetValue(0).ToString() == "1")
                    {
                        Coffee2.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();
                        Qpick2 = int.Parse(read.GetValue(3).ToString());
                    }
                    else if (read.GetValue(0).ToString() == "2")
                    {
                        coffee3.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();
                        Qpick3 = int.Parse(read.GetValue(3).ToString());
                    }
                    else if (read.GetValue(0).ToString() == "12")
                    {
                        Cofee4.Text = read.GetValue(2).ToString() + "-" + read.GetValue(3) + " ml " + "- R" + read.GetValue(4).ToString();
                        Qpick4 = int.Parse(read.GetValue(3).ToString());
                    }
                    

                   
                }






                sqlcon.Close();


            }
            catch (SqlException exce)
            {
                MessageBox.Show(exce.Message);
            }




        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        //Checkbox desserts 
        private void cboxD1_CheckedChanged(object sender, EventArgs e) 
        {

            if (cboxD1.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(lblD1.Text);
                myBasket.ItemType.Items.Add("Desserts"); 
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                lblTdesserts.Text = lblBasket.Text;
                Qpick4--;
            }
            else if (cboxD1.Checked == false)
            {
                myBasket.listBasket.Items.Remove(lblD1.Text);//Removing Items in the listbox
               
                myBasket.ItemType.Items.Remove("Desserts");
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                lblTdesserts.Text = lblBasket.Text;
                Qpick4++;
            }
        }

        private void cboxD2_CheckedChanged(object sender, EventArgs e)
        {
            if (cboxD2.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(lblD2.Text);
                myBasket.ItemType.Items.Add("Desserts");
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
               
                lblTdesserts.Text = lblBasket.Text;
                Qpick4--;
            }
            else if (cboxD2.Checked == false)
            {
                myBasket.listBasket.Items.Remove(lblD2.Text);//Removing Items in the listbox
               
                myBasket.ItemType.Items.Remove("Desserts");
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                lblTdesserts.Text = lblBasket.Text;
                Qpick4++;
            }
        }

        private void cboxD3_CheckedChanged(object sender, EventArgs e)
        {
            if (cboxD3.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(lblD3.Text);
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myBasket.ItemType.Items.Add("Desserts");
               
                lblTdesserts.Text = lblBasket.Text;
                Qpick4--;
            }
            else if (cboxD3.Checked == false)
            {
                myBasket.listBasket.Items.Remove(lblD3.Text);//Removing Items in the listbox
               
                myBasket.ItemType.Items.Remove("Desserts");
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                lblTdesserts.Text = lblBasket.Text;
                Qpick4++;
            }
        }

        private void cboxD4_CheckedChanged(object sender, EventArgs e)
        {
            if (cboxD4.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(lblD4.Text);
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myBasket.ItemType.Items.Add("Desserts");
               
                lblTdesserts.Text = lblBasket.Text;
                Qpick4--;
            }
            else if (cboxD1.Checked == false)
            {
                myBasket.listBasket.Items.Remove(lblD4.Text);//Removing Items in the listbox
                myBasket.ItemType.Items.Remove("Desserts");
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();

                lblTdesserts.Text = lblBasket.Text;
                Qpick4++;
            }
        }

        private void cboxD5_CheckedChanged(object sender, EventArgs e)
        {
            if (cboxD5.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(lblD5.Text);
               
                myBasket.ItemType.Items.Add("Desserts");
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                lblTdesserts.Text = lblBasket.Text;
                Qpick4--;
            }
            else if (cboxD5.Checked == false)
            {
                myBasket.listBasket.Items.Remove(lblD5.Text);//Removing Items in the listbox
                
                myBasket.ItemType.Items.Add("Desserts");
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                lblTdesserts.Text = lblBasket.Text;
                Qpick4++;
            }
        }


        //The coffee check boxes
        private void cbCoffee1_CheckedChanged(object sender, EventArgs e)
        {
            if (cbCoffee1.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(Coffe1.Text);

                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                
                 myBasket.ItemType.Items.Add("Coffee"); ;
                lblTcoffee.Text = lblBasket.Text;
                Qpick4--;
            }
            else if (cbCoffee1.Checked == false)
            {
                myBasket.listBasket.Items.Remove(Coffe1.Text);//Removing Items in the listbox
                
                myBasket.ItemType.Items.Remove("Coffee"); ;
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                lblTcoffee.Text = lblBasket.Text;
                Qpick4++;
            }
        }

        private void cbCoffee2_CheckedChanged(object sender, EventArgs e)
        {
            if (cbCoffee2.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(Coffee2.Text);
                myBasket.ItemType.Items.Add("Coffee"); ;
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
               
                lblTcoffee.Text = lblBasket.Text;
                Qpick4--;
            }
            else if (cbCoffee2.Checked == false)
            {
                myBasket.listBasket.Items.Remove(Coffee2.Text);//Removing Items in the listbox
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myBasket.ItemType.Items.Remove("Coffee"); ;
                
                lblTcoffee.Text = lblBasket.Text;
                Qpick4++;
            }
        }

        private void cbCoffee3_CheckedChanged(object sender, EventArgs e)
        {
            if (cbCoffee3.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(coffee3.Text);
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
               
                myBasket.ItemType.Items.Add("Coffee"); ;
                lblTcoffee.Text = lblBasket.Text;
                Qpick4--;
            }
            else if (cbCoffee3.Checked == false)
            {
                myBasket.listBasket.Items.Remove(coffee3.Text);//Removing Items in the listbox
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myBasket.ItemType.Items.Remove("Coffee"); ;
                lblTcoffee.Text = lblBasket.Text;
                Qpick4++;
            }
        }

        private void cbCoffee4_CheckedChanged(object sender, EventArgs e)
        {
            if (cbCoffee4.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(cbCoffe4.Text);
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myBasket.ItemType.Items.Add("Coffee"); ;
              
                lblTcoffee.Text = lblBasket.Text;
                Qpick4--;
            }
            else if (cbCoffee4.Checked == false)
            {
                myBasket.listBasket.Items.Remove(cbCoffe4.Text);//Removing Items in the listbox
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myBasket.ItemType.Items.Add("Coffee"); ;
               
                lblTcoffee.Text = lblBasket.Text;
                Qpick4++;
            }
        }

        private void cbH1_Enter(object sender, EventArgs e) 
        {


            

        }

        private void tabControl1_Enter(object sender, EventArgs e)
        {

        }

        private void tabPage4_Enter(object sender, EventArgs e) ////Hot drinks tabpage enter
        {
            lblThdrinks.Text = lblBasket.Text;
        }


        private void tabPage3_DragOver(object sender, DragEventArgs e)
        {

        }

        private void cBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (cBox3.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(lbl3.Text);
                myBasket.ItemType.Items.Add("C"); ;
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                Qpick4--;
            }
            else if (cBox3.Checked == false)
            {
                myBasket.listBasket.Items.Remove(lbl3.Text);//Removing Items in the listbox
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                Qpick4++;
            }
        }

        private void cBoxEspresso_CheckedChanged(object sender, EventArgs e)
        {
            if (cBoxEspresso.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(lbl2.Text);
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myAdmin.lstOrders.Items.Add(lbl2.Text);
                Qpick4--;
            }
            else if (cBoxEspresso.Checked == false)
            {
                myBasket.listBasket.Items.Remove(lbl2.Text);//Removing Items in the listbox
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myAdmin.lstOrders.Items.Remove(lbl2.Text);
                Qpick4++;
            }
        }

        private void cbH1_CheckedChanged(object sender, EventArgs e) ///check box hot drinks 1
        {
            if (cbH1.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(lblH1.Text);
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myAdmin.lstOrders.Items.Add(lblH1.Text);
                myBasket.ItemType.Items.Add(Hotdrinks); 
                lblThdrinks.Text = lblBasket.Text;

                Qpick4--;
            }
            else if (cbH1.Checked == false)
            {
                myBasket.listBasket.Items.Remove(lblH1.Text);//Removing Items in the listbox
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myAdmin.lstOrders.Items.Remove(lblH1.Text);
                myBasket.ItemType.Items.Remove(Hotdrinks);
                lblThdrinks.Text = lblBasket.Text;
                Qpick4++;
            }
        }

        private void cbH2_CheckedChanged(object sender, EventArgs e)
        {
            if(cbH2.Checked)//Adding items in the listbox basket
            {
                
                myBasket.listBasket.Items.Add(lblH2.Text);
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myAdmin.lstOrders.Items.Add(lblH2.Text);
                lblThdrinks.Text = lblBasket.Text;
                Qpick4--;
            }
            else if (cbH2.Checked == false)
            {
                myBasket.listBasket.Items.Remove(lblH2.Text);//Removing Items in the listbox
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myAdmin.lstOrders.Items.Remove(lblH2.Text);
                lblThdrinks.Text = lblBasket.Text;
                Qpick4++;
            }
        }

        private void cbH3_CheckedChanged(object sender, EventArgs e)
        {
            if (cbH3.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(lblH3.Text);
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myAdmin.lstOrders.Items.Add(lblH3.Text);
                lblThdrinks.Text = lblBasket.Text;
                Qpick4--;
            }
            else if (cbH3.Checked == false)
            {
                myBasket.listBasket.Items.Remove(lblH3.Text);//Removing Items in the listbox
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myAdmin.lstOrders.Items.Remove(lblH3.Text);
                lblThdrinks.Text = lblBasket.Text;
                Qpick4++;
            }
        }

        private void cbH4_CheckedChanged(object sender, EventArgs e)
        {
            if (cbH4.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(lblH4.Text);
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myAdmin.lstOrders.Items.Add(lblH4.Text);
                lblThdrinks.Text = lblBasket.Text;
                Qpick4--;
            }
            else if (cbH4.Checked == false)
            {
                myBasket.listBasket.Items.Remove(lblH4.Text);//Removing Items in the listbox
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myAdmin.lstOrders.Items.Remove(lblH4.Text);
                lblThdrinks.Text = lblBasket.Text;
                Qpick4++;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            myBasket.ShowDialog(); //calling the basket form by the picture box
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            myBasket.ShowDialog(); //calling the basket form by the picture box
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            myBasket.ShowDialog(); //calling the basket form by the picture box
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cBoxEspresso_CheckedChanged_1(object sender, EventArgs e)
        {

            if (cBoxEspresso.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(lbl2.Text);
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString(); //displaying the number of items in the basket
                myAdmin.lstOrders.Items.Add(lbl2.Text);
                Qpick3--;

            }
            
            else if (cBoxEspresso.Checked == false)
            {
                myBasket.listBasket.Items.Remove(lbl2.Text);//Removing Items in the listbox
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString(); //displaying the number of items in the basket
                myAdmin.lstOrders.Items.Remove(lbl2.Text);
                Qpick3++;
            }

        }

        private void cBoxGreenTea_CheckedChanged_1(object sender, EventArgs e)
        {
            if (cBox3.Checked)//Adding items in the listbox basket
            {
                myBasket.listBasket.Items.Add(lbl3.Text);
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myAdmin.lstOrders.Items.Add(lbl3.Text);
                Qpick4--;
            }
            else if (cBox3.Checked == false)
            {
                myBasket.listBasket.Items.Remove(lbl3.Text);//Removing Items in the listbox
                lblBasket.Text = myBasket.listBasket.Items.Count.ToString();
                myAdmin.lstOrders.Items.Add(lbl3.Text);
                Qpick4++;
            }
        }

    
      

        private void eXITToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            CreateAcc account = new CreateAcc();
            account.Show();
            this.Close();
        }
    }
}
