﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Cafe_Project;
using System.IO;

namespace BeetleCaf_Project
{
    public partial class Admin : Form
    {

        string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Users.mdf;Integrated Security=True";
        SqlConnection conn;
        SqlDataAdapter adapter;
        DataSet dataset;
        public Admin()
        {
            InitializeComponent();
        }

        public void refreshForm()
        {
            try
            {
                conn = new SqlConnection(constr);


                conn.Open();

                string comm = @"SELECT * FROM Items";
                SqlCommand command = new SqlCommand(comm, conn);
                adapter = new SqlDataAdapter();
                adapter.SelectCommand = command;

                dataset = new DataSet();

                adapter.Fill(dataset, "Items");

                dataGridView1.DataSource = dataset;
                dataGridView1.DataMember = "Items";


                conn.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);

            }
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            refreshForm();

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string search = txtSearch.Text;

            try
            {
                conn = new SqlConnection(constr);

                conn.Open();

                string comm = @"Select * FROM Items WHERE Item_ID LIKE '%" + search + "%' OR Item_Type LIKE '%" + search + "%' OR Item_Name LIKE '%" + search + "%'";
                SqlCommand command = new SqlCommand(comm, conn);
                adapter = new SqlDataAdapter();
                adapter.SelectCommand = command;

                dataset = new DataSet();

                adapter.Fill(dataset, "Item");

                dataGridView1.DataSource = dataset;
                dataGridView1.DataMember = "Item";

                conn.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);

            }

        }




        private void btnDelete_Click(object sender, EventArgs e)
        {
            Admin_Deleter deleter = new Admin_Deleter();
            deleter.Show();
            this.Close();


        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Update updateForm = new Update();
            updateForm.Show();
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddItem addForm = new AddItem();
            addForm.Show();
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void Orders_Enter(object sender, EventArgs e)
        {
            try
            {


                SqlConnection connect = new SqlConnection(constr);
                connect.Open();
                SqlCommand cmd = new SqlCommand(@"SELECT * FROM OrderTable", connect);
                SqlDataReader reader = cmd.ExecuteReader();

                lstOrders.Items.Add("Name\tItem Name\tType\tTotal"); 
                while (reader.Read())
                {
                    lstOrders.Items.Add(reader.GetString(1).ToString() + "\t" + reader.GetValue(2).ToString() + "\t" + reader.GetValue(3).ToString() + "\tR" + reader.GetValue(4).ToString());


                }
                conn.Close(); 
            }
            catch (SqlException exce)
            {
                MessageBox.Show(exce.Message); 

            }

        }
    }
}
