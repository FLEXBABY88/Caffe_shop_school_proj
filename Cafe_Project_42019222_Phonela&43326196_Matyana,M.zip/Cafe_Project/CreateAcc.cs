﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;

namespace Cafe_Project
{
    public partial class CreateAcc : Form
    {
        public CreateAcc()
        {
            InitializeComponent();
        }
        String path = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Nhlanhla\Desktop\New folder\Cafe_Project\Users.mdf"";Integrated Security=True"; 
        private void btnSignUp_Click(object sender, EventArgs e)
        {

            try
            {
                SqlDataAdapter adapter; 
                SqlConnection connect = new SqlConnection(path);
                connect.Open();
                SqlCommand cmd = new SqlCommand(@"INSERT INTO Users VALUES('" + txtUsername.Text + "','" + txtEmail.Text +  "','" +  txtPassword.Text +"')", connect);
                adapter = new SqlDataAdapter();
                adapter.InsertCommand= cmd;
                adapter.InsertCommand.ExecuteNonQuery();
                connect.Close();


            }
            catch (SqlException exce)
            {
                MessageBox.Show(exce.Message);
            }
            txtEmail.Clear();
            txtUsername.Clear();
            txtPassword.Clear();
             Login login = new Login();
            login.Show();
            this.Hide();



        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            if(txtUsername.Text!="")
            {
                errorProvider1.SetError(txtUsername, ""); 
            }
            else
            {
                errorProvider1.SetError(txtUsername, "Username field is required");
            }
        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

            if (txtEmail.Text != "")
            {
                errorProvider1.SetError(txtEmail, "");
            }
            else
            {
                errorProvider1.SetError(txtEmail, "Email field is required");
            }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            


            if (txtPassword.Text != "")
            {
                errorProvider1.SetError(txtPassword, "");
            }
            else
            {
                errorProvider1.SetError(txtPassword, "Password field is  required");
            }
        }

        private void btnlogIn_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide(); 
        }
    }
}

