﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Cafe_Project
{
    public partial class ForgotPassword : Form
    {
        public ForgotPassword()
        {
            InitializeComponent();
        }


        String path = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Nhlanhla\Desktop\New folder\Cafe_Project\Users.mdf"";Integrated Security=True";
       
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked != true)
            {
                checkBox1.Text = "SHOW";
                txtPassword.UseSystemPasswordChar = true;
            }
            else
            {
                checkBox1.Text = "HIDE";
                txtPassword.UseSystemPasswordChar = false;
            }
        }

        private void ForgotPassword_Load(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

            if (txtPassword.Text != "")
            {
                errorProvider1.SetError(txtPassword, "");
            }
            else
            {
                errorProvider1.SetError(txtPassword, "Password field is  required");
            }
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

            if (txtUsername.Text != "")
            {
                errorProvider1.SetError(txtUsername, "");
            }
            else
            {
                errorProvider1.SetError(txtUsername, "Username field is  required");
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connect = new SqlConnection(path);

                connect.Open();
                SqlCommand cmd = new SqlCommand("UPDATE Users set Password=@Password WHERE Email =@email ", connect);
                
                cmd.Parameters.AddWithValue(@"Password", txtPassword.Text);
                cmd.Parameters.AddWithValue(@"email ", txtUsername.Text);
                cmd.ExecuteNonQuery();


                connect.Close();
                cmd.Dispose(); 
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Password changed successfully ");
            CreateAcc acc = new CreateAcc();
            acc.Show();
            this.Close(); 
        }
    }
}
