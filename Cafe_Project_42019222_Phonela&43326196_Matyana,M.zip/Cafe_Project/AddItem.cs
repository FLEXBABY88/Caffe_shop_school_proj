﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BeetleCaf_Project
{
    public partial class AddItem : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Users.mdf;Integrated Security=True");
        public AddItem()
        {
            InitializeComponent();
        }

        

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string comm = @"INSERT INTO Items(Item_ID, Item_Type, Item_Name, Quantity, Price) VALUES(@value1, @value2, @value3, @value4, @value5)";

                conn.Open();

                SqlCommand command = new SqlCommand(comm, conn);
                command.Parameters.AddWithValue("@value1", txtID.Text);
                command.Parameters.AddWithValue("@value2", txtType.Text);
                command.Parameters.AddWithValue("@value3", txtName.Text);
                command.Parameters.AddWithValue("@value4", txtQuantity.Text);
                command.Parameters.AddWithValue("@value5", txtPrice.Text);

                command.ExecuteNonQuery();

                conn.Close();

                MessageBox.Show("Item_ID: " + txtID.Text + ", successfully added.");
            }

            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }

            Admin myForm = new Admin();
            myForm.Show();
            myForm.refreshForm();
            this.Close();
        }
    }
    
}
