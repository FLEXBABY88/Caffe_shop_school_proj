﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.Remoting.Contexts;

namespace Cafe_Project
{
    public partial class Basket : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Nhlanhla\Desktop\New folder\Cafe_Project\Users.mdf"";Integrated Security=True");
       
        string itemName;
        string itemType;
        public Basket()
        {
            InitializeComponent();
          

        }

       
        double total = 0;

        private void Basket_Load(object sender, EventArgs e)
        {
            


            
            if(listBasket.Items.Count==0) //if there is nothing in the basket
            {
                lblChectout.Visible = false;
                listBasket.Visible = false;
                btnCheckout.Visible = false;
                pictureBox1.Visible = true;
                label1.Visible = true;
            }
            else if(listBasket.Items.Count>0) //if there is something in the listbox
            {
                lblChectout.Visible = true;
                listBasket.Visible = true;
                btnCheckout.Visible = true;
                pictureBox1.Visible = false;
                label1.Visible = false;

              
               
                double price = 0.0;

                listTotal.Items.Add("*************************************************");
                listTotal.Items.Add("====================TOTAL=========================");
                listTotal.Items.Add("*************************************************");

                foreach (var item in listBasket.Items) //getting the value of money in the listbox items and adding the totals
                {
                    int index = item.ToString().IndexOf("- R");

                    price = double.Parse(item.ToString().Substring(index + 3, 2));


                    total += price;

                }
                listTotal.Items.Add("R  "+total+".00");



            }




        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You need to order first "); 
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
       
            foreach (var item in listBasket.Items) //getting the value of money in the listbox items and adding the totals
            {
                int index = item.ToString().IndexOf("-");

                itemName = item.ToString().Substring(0, index);
               

            }

            foreach (var item in ItemType.Items) //getting the value of money in the listbox items and adding the totals
            {


                itemType = item.ToString();
                

            }

            MessageBox.Show("Oder successfully placed ");  //Check out button clicked 

            updateDatabase();




        }

       public void updateDatabase()
        {
            try
            {
                conn.Open();
                SqlCommand comm = new SqlCommand(@"UPDATE OrderTable set ItemName=@Name,ItemType =@Type ,Price = @Total WHERE Id IS NOT NULL AND ItemName IS NULL", conn);

                comm.Parameters.AddWithValue(@"Name", itemName);
                comm.Parameters.AddWithValue(@"Type ", itemType);
                comm.Parameters.AddWithValue(@"Total", total);

                comm.ExecuteNonQuery();
                conn.Close();

            }catch(SqlException exce)
            {
                MessageBox.Show(exce.Message); 
            }
           
           
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            Basket basket = new Basket();//button back to the menu page
            basket.Show();
            this.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 myMdi = new Form1();
            myMdi.Close();
            Basket basket = new Basket();
            basket.Close(); 
        }
    }
}
