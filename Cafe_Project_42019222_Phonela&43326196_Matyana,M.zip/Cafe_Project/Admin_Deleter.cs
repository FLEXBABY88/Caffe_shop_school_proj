﻿using BeetleCaf_Project;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafe_Project
{
    public partial class Admin_Deleter : Form
    {
        public Admin_Deleter()
        {
            InitializeComponent();
        }


        string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Users.mdf;Integrated Security=True";
        SqlConnection conn;
        SqlDataAdapter adapter;
        DataSet dataset;
        private void btnDelete_Click(object sender, EventArgs e)
        {

            try
            {
                conn = new SqlConnection(constr);
                conn.Open();

                string comm = @"DELETE FROM items WHERE Item_Name='"+txtDelete.Text+"'";
                SqlCommand command = new SqlCommand(comm, conn);
                adapter = new SqlDataAdapter();
                adapter.DeleteCommand = command;
                adapter.DeleteCommand.ExecuteNonQuery();


                conn.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);

            }

            MessageBox.Show("Item deleted successfully.");

            Admin admin = new Admin();
            admin.Show();
            this.Close(); 
        }
    }
}
