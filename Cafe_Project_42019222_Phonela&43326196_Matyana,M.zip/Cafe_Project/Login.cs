﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Reflection.Emit;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using BeetleCaf_Project;
using System.Security.Cryptography.X509Certificates;

namespace Cafe_Project
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        Admin myForm = new Admin();
        public string custName;

        String path = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Nhlanhla\Desktop\New folder\Cafe_Project\Users.mdf"";Integrated Security=True"; 
        private void btnSignIn_Click(object sender, EventArgs e)
        {
          

            if(cmbUserType.SelectedItem.ToString()=="Customer")
            {
                //validating  the users if they exist in  the database

                try
                {


                    SqlConnection connect = new SqlConnection(path);
                    connect.Open();
                    SqlCommand cmd = new SqlCommand(@"SELECT * FROM Users ", connect);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {



                        if (reader.GetValue(0).ToString() == txtUsername.Text) //checking if the username does exists to the database
                        {


                            lblData.Text = reader.GetValue(0).ToString();
                       
                            mytrueUser.Text = "true";

                            if (reader.GetValue(2).ToString() == txtUserPassword.Text) //checking if the password for the specified user matches and exists to the database
                            {
                                truePassword.Text = "true";
                            }
                            else
                            {

                                truePassword.Text = "false";
                            }
                        }
                        else
                        {
                            mytrueUser.Text = "false";      //else if the username does not exist 

                        }



                    }



                    connect.Close();
                    if (mytrueUser.Text == "true" || lblData.Text == "Flex")
                    {
                        if (truePassword.Text == "true")
                        {
                            MessageBox.Show("Welcomeback " + lblData.Text, " Confirmed", MessageBoxButtons.OK, MessageBoxIcon.Information);






                          
                            checkBox1.Checked = false;
                           


                            Menu menu = new Menu();
                            menu.Show(); //calling the menu 
                            this.Close(); //closing this form afterwards


                        }
                        else ///if the entered password was incorrect 
                        {
                            MessageBox.Show("Incorrect password");
                            lblUsername.Visible = true;
                            btnFpassword.Visible = true;
                            lblUsername.Text = lblData.Text;
                            lblSignup.Visible = false;
                            btnSignUp.Visible = false;






                        }

                    }
                    else
                    {
                        MessageBox.Show("Invalid user name!");
                    }

                }
                catch (SqlException exce)
                {
                    MessageBox.Show(exce.Message);
                }
            }
            else if (cmbUserType.SelectedItem.ToString() == "Administrator")
            {
                //validating the admin ??


                try
                {


                    SqlConnection connect = new SqlConnection(path);
                    connect.Open();
                    SqlCommand cmd = new SqlCommand(@"SELECT * FROM Admin", connect);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {



                        if (reader.GetValue(1).ToString() == txtUsername.Text) //checking if the username does exists to the database
                        {


                            lblData.Text = reader.GetValue(1).ToString();

                            mytrueUser.Text = "true";

                            if (reader.GetValue(2).ToString() == txtUserPassword.Text) //checking if the password for the specified user matches and exists to the database
                            {
                                truePassword.Text = "true";
                            }
                            else
                            {

                                truePassword.Text = "false";
                            }
                        }
                        else
                        {
                            mytrueUser.Text = "false";      //else if the username does not exist 

                        }



                    }



                    connect.Close();
                    if (mytrueUser.Text == "true")
                    {
                        if (truePassword.Text == "true")
                        {
                            MessageBox.Show("Welcomeback " + lblData.Text, " Confirmed", MessageBoxButtons.OK, MessageBoxIcon.Information);






                           

                            checkBox1.Checked = false;

                            myForm.Show();

                            //closing this form afterwards


                        }
                        else ///if the entered password was incorrect 
                        {
                            MessageBox.Show("Incorrect password");
                            lblUsername.Visible = true;
                            btnFpassword.Visible = true;
                            lblUsername.Text = lblData.Text;
                            lblSignup.Visible = false;
                            btnSignUp.Visible = false;






                        }

                    }
                    else
                    {
                        MessageBox.Show("Invalid Admin name!");
                    }

                }
                catch (SqlException exce)
                {
                    MessageBox.Show(exce.Message);
                }
              

            }
            else if(cmbUserType.SelectedIndex.ToString()=="")
            {
                MessageBox.Show("Must select user type ", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error); 
            }
                    
           
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            //hiding and showing the user textbox password
            if (checkBox1.Checked != true)
            {
                checkBox1.Text = "SHOW";
                txtUserPassword.UseSystemPasswordChar = true;
            }
            else
            {
                checkBox1.Text = "HIDE";
                txtUserPassword.UseSystemPasswordChar = false; 
            }
        }

        

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            //trying to dictect empty spaces left from the textbox
            if (txtUsername.Text != "")
            {
                errorProvider2.SetError(txtUsername, "");
            }
            else
            {
                errorProvider2.SetError(txtUsername, "Username field is required");
            }
        }




      

        private void txtUserPassword_TextChanged(object sender, EventArgs e)
        {//trying to dictect empty spaces left from the textbox
            if (txtUserPassword.Text != "")
            {
                errorProvider2.SetError(txtUserPassword, "");
            }
            else
            {
                errorProvider2.SetError(txtUserPassword, "User password is  required");
            }
        }

        private void btnFpassword_Click(object sender, EventArgs e)
        {
            ForgotPassword forgot = new ForgotPassword();
            forgot.Show();
            this.Close();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            CreateAcc create = new CreateAcc();//if the user wants to sign up account 
            create.Show();
            this.Close(); 
        }










        private void cmbUserType_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
