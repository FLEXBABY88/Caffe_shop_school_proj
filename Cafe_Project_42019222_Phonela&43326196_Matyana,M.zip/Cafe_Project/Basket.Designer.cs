﻿namespace Cafe_Project
{
    partial class Basket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Basket));
            this.listBasket = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCheckout = new System.Windows.Forms.Button();
            this.lblChectout = new System.Windows.Forms.Label();
            this.listTotal = new System.Windows.Forms.ListBox();
            this.btnMenu = new System.Windows.Forms.Button();
            this.ItemType = new System.Windows.Forms.ListBox();
            this.btnExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // listBasket
            // 
            this.listBasket.BackColor = System.Drawing.Color.DarkKhaki;
            this.listBasket.ForeColor = System.Drawing.SystemColors.MenuText;
            this.listBasket.FormattingEnabled = true;
            this.listBasket.Location = new System.Drawing.Point(12, 64);
            this.listBasket.Name = "listBasket";
            this.listBasket.Size = new System.Drawing.Size(641, 238);
            this.listBasket.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(306, 164);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label1.Location = new System.Drawing.Point(270, 264);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "No Items in the basket ";
            // 
            // btnCheckout
            // 
            this.btnCheckout.BackColor = System.Drawing.Color.Goldenrod;
            this.btnCheckout.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCheckout.Location = new System.Drawing.Point(688, 203);
            this.btnCheckout.Name = "btnCheckout";
            this.btnCheckout.Size = new System.Drawing.Size(91, 39);
            this.btnCheckout.TabIndex = 3;
            this.btnCheckout.Text = "Check out !";
            this.btnCheckout.UseVisualStyleBackColor = false;
            this.btnCheckout.Click += new System.EventHandler(this.btnCheckout_Click);
            // 
            // lblChectout
            // 
            this.lblChectout.AutoSize = true;
            this.lblChectout.BackColor = System.Drawing.Color.Khaki;
            this.lblChectout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChectout.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblChectout.Location = new System.Drawing.Point(212, 20);
            this.lblChectout.Name = "lblChectout";
            this.lblChectout.Size = new System.Drawing.Size(258, 20);
            this.lblChectout.TabIndex = 4;
            this.lblChectout.Text = "Items in the basket are ready to go ";
            // 
            // listTotal
            // 
            this.listTotal.BackColor = System.Drawing.Color.DarkKhaki;
            this.listTotal.FormattingEnabled = true;
            this.listTotal.Location = new System.Drawing.Point(12, 308);
            this.listTotal.Name = "listTotal";
            this.listTotal.Size = new System.Drawing.Size(641, 95);
            this.listTotal.TabIndex = 5;
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.Color.Goldenrod;
            this.btnMenu.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnMenu.Location = new System.Drawing.Point(124, 452);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(110, 29);
            this.btnMenu.TabIndex = 6;
            this.btnMenu.Text = "Back to Menu";
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // ItemType
            // 
            this.ItemType.FormattingEnabled = true;
            this.ItemType.Location = new System.Drawing.Point(530, 426);
            this.ItemType.Name = "ItemType";
            this.ItemType.Size = new System.Drawing.Size(120, 43);
            this.ItemType.TabIndex = 7;
            this.ItemType.Visible = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Goldenrod;
            this.btnExit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnExit.Location = new System.Drawing.Point(342, 452);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(110, 29);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Basket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 525);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.ItemType);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.listTotal);
            this.Controls.Add(this.lblChectout);
            this.Controls.Add(this.btnCheckout);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.listBasket);
            this.Name = "Basket";
            this.Text = "Basket";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Basket_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.ListBox listBasket;
        private System.Windows.Forms.Button btnCheckout;
        public System.Windows.Forms.Label lblChectout;
        private System.Windows.Forms.ListBox listTotal;
        private System.Windows.Forms.Button btnMenu;
        public System.Windows.Forms.ListBox ItemType;
        private System.Windows.Forms.Button btnExit;
    }
}