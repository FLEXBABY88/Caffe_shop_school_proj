﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BeetleCaf_Project
{
    public partial class Update : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Users.mdf;Integrated Security=True");


        public Update()
        {
            InitializeComponent();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string comm = @"UPDATE Items SET Quantity = @value1 WHERE Item_ID = @value2";

                conn.Open();

                SqlCommand command = new SqlCommand(comm, conn);
                command.Parameters.AddWithValue("@value1", txtName.Text);
                command.Parameters.AddWithValue("@value2", txtID.Text);
                command.ExecuteNonQuery();

                conn.Close();

                MessageBox.Show("Item_ID: " + txtID.Text + ", successfully update.");
            }

            catch(SqlException error)
            {
                MessageBox.Show(error.Message);
            }

            this.Close();

            Admin myForm = new Admin();
            myForm.Show();
            myForm.refreshForm();
        }
    }
}
